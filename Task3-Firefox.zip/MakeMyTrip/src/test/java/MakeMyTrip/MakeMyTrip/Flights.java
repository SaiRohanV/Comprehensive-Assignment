package MakeMyTrip.MakeMyTrip;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;

public class Flights {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Home\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.makemytrip.com");
		driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]")).click();
		WebElement flights = driver.findElement(By.xpath("//a[contains(@href, 'flights')]]"));
		WebElement oneway = driver.findElement(By.xpath("//li[contains(@class, 'oneway')]"));
		WebElement from = driver.findElement(By.xpath("//input[@id='fromCity']"));
		WebElement to = driver.findElement(By.xpath("//input[@id='toCity']"));
		
		flights.click();
		oneway.click();
		from.sendKeys("Hyderabad");
		to.sendKeys("Delhi");
		
		driver.close();
				
	}

}
