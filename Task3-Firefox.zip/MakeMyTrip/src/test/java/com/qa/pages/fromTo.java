package com.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class fromTo extends TestBase{
	@Test
	
    public void searchFlights() {
       
		setUp();

        driver.get("https://www.makemytrip.com");
		driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]")).click();
		WebElement flights = driver.findElement(By.xpath("//a[contains(@href, 'flights')]]"));
		WebElement oneway = driver.findElement(By.xpath("//li[contains(@class, 'oneway')]"));
		WebElement from = driver.findElement(By.xpath("//input[@id='fromCity']"));
		WebElement to = driver.findElement(By.xpath("//input[@id='toCity']"));
		
		flights.click();
		oneway.click();
		from.sendKeys("Hyderabad");
		to.sendKeys("Delhi");
		
		tearDown();
    }

   
}
