package com.qa.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class TestBase {

    protected WebDriver driver;

    @BeforeMethod
    public void setUp() {
        // Set up the driver
        System.setProperty("webdriver.firefox.driver", "C:\\Users\\SAIROHANV\\Downloads\\chromedriver_win32\\geckodriver.exe");
        driver = new FirefoxDriver();
    }

    @AfterMethod
    public void tearDown() {
        // Close the browser
        driver.close();
    }
    
}