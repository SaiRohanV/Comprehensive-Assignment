package com.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class VerifyLogo extends TestBase{
	@Test 
    public void verifyMakeMyTripLogo() {
        // Navigate to the MakeMyTrip website
       setUp();
        // Find the MakeMyTrip logo
		WebElement logo = driver.findElement(By.xpath("//*[@id=\"SW\"]/div[1]/div[1]/a/picture/img"));

        // Check if the logo is present on the page
        if (logo != null) {
            System.out.println("MakeMyTrip logo is present on the page");
        } else {
            System.out.println("MakeMyTrip logo is not present on the page");
        }
        tearDown();
	}
}
