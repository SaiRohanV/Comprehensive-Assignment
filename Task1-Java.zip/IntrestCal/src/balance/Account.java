package balance;

class Account {
    protected double interest;
	protected double balance;

    public Account(double interest) {
        this.interest = interest/100;
    }

    public void calculateInterest() {
        double interestAmount = interest * this.balance;
        this.balance += interestAmount;
    }

    public double getInterest() {
        return interest;
    }

    public void setInterest(double interest) {
        this.interest = interest;
    }
}