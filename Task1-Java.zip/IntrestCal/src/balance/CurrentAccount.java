package balance;

class CurrentAccount extends Account {

    public CurrentAccount(double interest, double balance) {
        super(interest);
        this.balance = balance;
    }

    @Override
    public void calculateInterest() {
        super.calculateInterest();

        // Add an additional 0.25% interest for current accounts
        double interestAmount = interest * this.balance + 0.0025 * this.balance;
        this.balance += interestAmount;
    }
}