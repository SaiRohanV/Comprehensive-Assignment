package balance;

class SavingsAccount extends Account {

    public SavingsAccount(double interest, double balance) {
        super(interest);
        this.balance = balance;
    }

    @Override
    public void calculateInterest() {
        super.calculateInterest();

        // Add an additional 0.5% interest for savings accounts
        double interestAmount = interest * this.balance + 0.005 * this.balance;
        this.balance += interestAmount;
    }
}