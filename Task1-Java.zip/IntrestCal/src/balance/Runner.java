package balance;

public class Runner {

    public static void main(String[] args) {
        SavingsAccount savingsAccount = new SavingsAccount(3, 1000);
        savingsAccount.calculateInterest();
        System.out.println("Savings account balance: " + savingsAccount.balance);

        CurrentAccount currentAccount = new CurrentAccount(2, 2000);
        currentAccount.calculateInterest();
        System.out.println("Current account balance: " + currentAccount.balance);
    }
}
